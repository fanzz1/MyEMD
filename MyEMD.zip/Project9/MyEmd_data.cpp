//
// File: MyEmd_data.cpp
//
// MATLAB Coder version            : 5.5
// C/C++ source code generated on  : 26-Feb-2024 09:41:51
//

// Include Files
#include "MyEmd_data.h"
#include "rt_nonfinite.h"

// Variable Definitions
omp_nest_lock_t MyEmd_nestLockGlobal;

//
// File trailer for MyEmd_data.cpp
//
// [EOF]
//
