//
// File: xzsvdc.h
//
// MATLAB Coder version            : 5.5
// C/C++ source code generated on  : 26-Feb-2024 09:41:51
//

#ifndef XZSVDC_H
#define XZSVDC_H

// Include Files
#include "rtwtypes.h"
#include "coder_array.h"
#include <cstddef>
#include <cstdlib>

// Function Declarations
namespace coder {
namespace internal {
namespace reflapack {
void xzsvdc(::coder::array<double, 2U> &A, ::coder::array<double, 1U> &S);

}
} // namespace internal
} // namespace coder

#endif
//
// File trailer for xzsvdc.h
//
// [EOF]
//
