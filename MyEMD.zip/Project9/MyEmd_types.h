//
// File: MyEmd_types.h
//
// MATLAB Coder version            : 5.5
// C/C++ source code generated on  : 26-Feb-2024 09:41:51
//

#ifndef MYEMD_TYPES_H
#define MYEMD_TYPES_H

// Include Files
#include "rtwtypes.h"
#define MAX_THREADS omp_get_max_threads()

#endif
//
// File trailer for MyEmd_types.h
//
// [EOF]
//
