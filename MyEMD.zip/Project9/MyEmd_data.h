//
// File: MyEmd_data.h
//
// MATLAB Coder version            : 5.5
// C/C++ source code generated on  : 26-Feb-2024 09:41:51
//

#ifndef MYEMD_DATA_H
#define MYEMD_DATA_H

// Include Files
#include "rtwtypes.h"
#include "omp.h"
#include <cstddef>
#include <cstdlib>

// Variable Declarations
extern omp_nest_lock_t MyEmd_nestLockGlobal;

#endif
//
// File trailer for MyEmd_data.h
//
// [EOF]
//
