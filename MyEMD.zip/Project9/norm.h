//
// File: norm.h
//
// MATLAB Coder version            : 5.5
// C/C++ source code generated on  : 26-Feb-2024 09:41:51
//

#ifndef NORM_H
#define NORM_H

// Include Files
#include "rtwtypes.h"
#include "coder_array.h"
#include <cstddef>
#include <cstdlib>

// Function Declarations
namespace coder {
double b_norm(const ::coder::array<double, 2U> &x);

}

#endif
//
// File trailer for norm.h
//
// [EOF]
//
